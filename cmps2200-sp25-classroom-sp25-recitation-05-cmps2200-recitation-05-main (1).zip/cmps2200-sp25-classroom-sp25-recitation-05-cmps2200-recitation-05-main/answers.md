# CMPS 2200 Reciation 5
## Answers

**Name:**_________________________


Place all written answers from `recitation-05.md` here for easier grading.







- **1b.**




- **1c.**
